from pdfminer.high_level import extract_text
import docx2txt
import re

def extract_resume_text(path):
    if path.endswith('.pdf'):
        return extract_text(path)
    elif path.endswith('.docx'):
        return docx2txt.process(path)
    else:
        return ""

def extract_experience(text):
    exp_regex = r'(\d+)\+?\s*(?:years|yrs)\s*(?:of)?\s*experience'
    matches = re.findall(exp_regex, text.lower())
    if matches:
        return max(map(int, matches))
    return 0