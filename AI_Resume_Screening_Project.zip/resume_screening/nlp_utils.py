import re
import nltk
from nltk.corpus import stopwords
from sentence_transformers import SentenceTransformer, util
from transformers import pipeline

nltk.download('stopwords')
model = SentenceTransformer('all-MiniLM-L6-v2')
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

def clean_text(text):
    text = re.sub(r'\W', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    text = text.lower()
    tokens = text.split()
    tokens = [word for word in tokens if word not in stopwords.words('english')]
    return ' '.join(tokens)

def match_score(resume_text, job_desc_text):
    resume_embedding = model.encode(resume_text, convert_to_tensor=True)
    jd_embedding = model.encode(job_desc_text, convert_to_tensor=True)
    return util.pytorch_cos_sim(resume_embedding, jd_embedding).item()

def summarize_resume(text):
    text = text[:1024]
    summary = summarizer(text, max_length=100, min_length=30, do_sample=False)
    return summary[0]['summary_text']