import streamlit as st
from parser import extract_resume_text, extract_experience
from nlp_utils import clean_text, match_score, summarize_resume
import pandas as pd

st.title("AI Resume Screening System")

uploaded_files = st.file_uploader("Upload Resumes (PDF/DOCX)", type=['pdf', 'docx'], accept_multiple_files=True)
job_desc = st.text_area("Paste Job Description Here")
min_exp = st.slider("Minimum Years of Experience", 0, 20, 2)
show_summary = st.checkbox("Show Resume Summaries")

if st.button("Evaluate Resumes") and uploaded_files and job_desc:
    scores = []
    cleaned_jd = clean_text(job_desc)
    progress = st.progress(0)

    for i, file in enumerate(uploaded_files):
        with open(os.path.join("resumes", file.name), "wb") as f:
            f.write(file.read())

        text = extract_resume_text(f"resumes/{file.name}")
        cleaned_resume = clean_text(text)
        score = match_score(cleaned_resume, cleaned_jd)
        exp = extract_experience(text)

        if exp >= min_exp:
            scores.append((file.name, round(score * 100, 2), exp))
            if show_summary:
                summary = summarize_resume(text)
                st.write(f"**Summary for {file.name}:** {summary}")

        progress.progress((i + 1) / len(uploaded_files))

    sorted_scores = sorted(scores, key=lambda x: x[1], reverse=True)
    st.subheader("Resume Rankings:")
    for name, score, exp in sorted_scores:
        st.write(f"{name} | Match: {score}% | Experience: {exp} yrs")

    df = pd.DataFrame(sorted_scores, columns=["Resume", "Score (%)", "Experience (yrs)"])
    df.to_csv("ranked_resumes.csv", index=False)
    st.success("Results saved to 'ranked_resumes.csv'")